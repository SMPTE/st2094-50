import scipy.interpolate
import numpy as np
import matplotlib.pyplot as plt
import copy

colors = plt.rcParams['axes.prop_cycle'].by_key()['color']

style_base = (0, ())
style_altr = [(0, (5, 2)), (0, (5, 2, 1, 2))]
style_intr = (0, (1, 2))

grid_style = (0, (1, 4))

# Function to evaluate a piecewise cubic, with
# clamp-like right hand extrapolation behavior
def EvalPiecewiseCubic(x, x_cp, y_cp, m_cp):
  piecewise_conditions = []
  piecewise_functions = []

  def SegmentEval(xx, x0, x1, y0, y1, m0, m1):
    t = (xx - x0) / (x1 - x0)
    m0 *= (x1 - x0)
    m1 *= (x1 - x0)
    c3 = (2*y0 + m0 - 2*y1 + m1);
    c2 = (-3.0*y0 + 3*y1 - 2*m0 - m1);
    c1 = m0;
    c0 = y0;
    return c0 + t*(c1 + t*(c2 + t*c3));

  y = np.zeros(x.shape)

  for i in range(1, len(x_cp)):
    I = (x > x_cp[i-1]) & (x <= x_cp[i])
    y[I] = SegmentEval(x[I], x_cp[i-1], x_cp[i], y_cp[i-1], y_cp[i], m_cp[i-1], m_cp[i])

  # left hand extension
  I = x <= x_cp[0]
  y[I] = y_cp[0]

  # right hand extension
  # we want g to have the property that
  # x * np.exp2(-g) = x_cp[n-1] * np.exp2(-y_cp[n-1])
  I = x > x_cp[-1]
  y[I] = np.log2(np.exp2(y_cp[-1]) * x_cp[-1] / x[I])
  return y

# Evaluate a gain curve dictionary (stored in `C`) at points `x`
def EvalGainCurve(x, C):
  return EvalPiecewiseCubic(x, np.array([c["x"] for c in C]), np.array([c["y"] for c in C]), np.array([c["m"] for c in C]))

# Given a gain curve, sloppily compute the inverse gain curve
def InvertGainCurves(H, C, b_old, b_new):
  x_old = np.linspace(0, np.exp2(H[b_old]), 1000)
  x_cp_old = np.array([c["x"] for c in C[b_new]])
  G_old = [EvalGainCurve(x_old, c) for c in C]
  Y_old = [x_old * np.exp2(g) for g in G_old]

  x = Y_old[b_new]
  x_cp = x_cp_old * np.exp2(EvalGainCurve(x_cp_old, C[b_new]))
  G = [np.log2((y+0.0001) / (x+0.0001)) for y in Y_old]
  G_fn = [scipy.interpolate.PchipInterpolator(x, g) for g in G]
  G_fn_prime = [g.derivative() for g in G_fn]

  Cinv = [[{"x":float(x), "y":float(G_fn[i](x)), "m":float(G_fn_prime[i](x))} for x in x_cp]
          for i in range(len(G))]
  return Cinv

# Return i, j such that H[i] <= h <= H[j].
def FindBoundIndex(H, H_target):
  i = -1
  Hi = -float('inf')
  j = -1
  Hj = float('inf')
  for k in range(len(H)):
    if H[k] <= H_target and H[k] > Hi:
      i = k
      Hi = H[k]
    if H[k] >= H_target and H[k] < Hj:
      j = k
      Hj = H[k]
  if i == -1:
    i = j
  if j == -1:
    j = i
  return i, j

# Compute the weights wi and wj for targeting HDR headroom H
def ComputeGainWeights(x, H, Hi, Hj):
  if Hi == Hj:
    wi = 1
  else:
    wi = np.minimum(np.maximum((H - Hj) / (Hi - Hj), 0), 1)
  wj = 1 - wi
  return wi, wj

# Compute the weighted gain at `x`, targeting `H_target`
def EvaluateWeightedGain(x, H_target, H, G):
  i, j = FindBoundIndex(H, H_target)
  print('%f = H_%d <= %f <= H_%d <= %f' %
        (H[i], i, H_target, j, H[j]))
  wi, wj = ComputeGainWeights(x, H_target, H[i], H[j])
  G_intr = wi * EvalGainCurve(x, G[i])
  if j != None:
    G_intr += wj * EvalGainCurve(x, G[j])
  print('w_%d=%f, w_%d=%f' % (i, wi, j, wj))
  return G_intr, i, j, wi, wj

# Compute and apply the weighted gain
def ComputeToneMap(x, H_target, H, G):
  G_intr, i, j, wi, wj = EvaluateWeightedGain(x, H_target, H[i], H[j], G[i], G[j])
  y = x * np.exp2(G_intr)
  return y, i, j, wi, wj

def InitFigure():
  # plt.figure(dpi=200, figsize=[8, 6])
  plt.figure()

# Convert tone map curve control points to gain curve control points
def ToneMapToGainCurve(x, y, m):
  y_new = np.log2(y / x)
  m_new = (x * m - y) / (np.log(2) * x * y)
  return x, y_new, m_new

# Evaluate a degree 2 Bezier segment (isn't there some numpy library
# for this?)
def EvaluateBezier(t, x_cp, y_cp):
  a_x =   x_cp[0] - 2*x_cp[1] + x_cp[2]
  b_x = 2*x_cp[1] - 2*x_cp[2]
  c_x =   x_cp[2]
  a_y =   y_cp[0] - 2*y_cp[1] + y_cp[2]
  b_y = 2*y_cp[1] - 2*y_cp[2]
  c_y =   y_cp[2]

  x = (a_x*t*t + b_x*t + c_x)
  y = (a_y*t*t + b_y*t + c_y)
  dx = (2*a_x*t + b_x)
  dy = (2*a_y*t + b_y)
  m = dy/dx
  I = np.argsort(x)
  return x[I], y[I], m[I]

# Given a degree 2 Bezier segment specifying a tone curve, return
# control points for the log2 gain curve
def BezierToGainCurveControlPoints(x_cp, y_cp, N=6):
  t = np.linspace(0, 1, N)
  x_cp, y_cp, m_cp = EvaluateBezier(t, x_cp, y_cp)
  x_cp, y_cp, m_cp = ToneMapToGainCurve(x_cp, y_cp, m_cp)
  return [{"x": float(x_cp[i]), "y": float(y_cp[i]), "m": float(m_cp[i])} for i in range(len(x_cp))]

# RWTMO Bezier computation
def RwtmoBezierControlPoints(N_c, N_t, N_w):
  return [1, 1 + 0.65 * (N_t / N_w - 1), N_c], [N_w, N_w + 0.65 * (N_t - N_w), N_t]

################################################################################
#
# Plots for ST 2094-50
#
################################################################################

H = [0, np.log2(4)]
C = []
M = np.exp2(H[-1])
Nw = [0.5, 1]
for i in range(len(H)):
  M = np.exp2(H[-1])
  x_cp, y_cp = RwtmoBezierControlPoints(M, np.exp2(H[i]), Nw[i])
  # if i == 0:
  #   x_cp = np.array([0.6, 0.6*(1+0.75), 4.0])
  #   y_cp = np.array([0.4, 0.4*(1+0.75), 1.0])
  C.append(BezierToGainCurveControlPoints(x_cp, y_cp, 6))


base_label = 'Baseline\n$H_1=H_\\text{baseline}=\\log_2(4)=2$'
altr_label = 'Alternate\n$H_0=H_{\\text{alt},0}=\\log_2(1)=0$'
intr_label = 'Adapted\n$H_\\text{target}=\\log_2(2)=1$'

x = np.linspace(0, M, 1000)

H_intr = 1
G_intr, i, j, wi, wj = EvaluateWeightedGain(x, H_intr, H, C)
Y_intr = x * np.exp2(G_intr)
Y = [x * np.exp2(EvalGainCurve(x, c)) for c in C]

x_cp_0 = np.array([d['x'] for d in C[0]])
g_cp_0 = EvalGainCurve(x_cp_0, C[0])
y_cp_0 = x_cp_0 * np.exp2(g_cp_0)

fig, (ax2, ax1) = plt.subplots(1, 2, figsize=[9, 3])
ax1.plot(x, Y[1],   color='k', linestyle=style_base    )
ax1.plot(x, Y[0],   color='k', linestyle=style_altr[0] )
ax1.plot(x, Y_intr, color='k', linestyle=style_intr    )
ax1.set_title('Tone mapping functions')
ax1.set_xlabel('Input relative linear value $x$')
ax1.scatter(x_cp_0, y_cp_0, color='k', facecolors='none', label='Control point\nmetadata items')
ax1.set_ylabel('Tone mapped relative linear value\n$x\\times 2^{\mathsf{Gain}(x))}$')

ax2.plot(x, EvalGainCurve(x, C[1]), color='k', linestyle=style_base,    label=base_label)
ax2.plot(x, EvalGainCurve(x, C[0]), color='k', linestyle=style_altr[0], label=altr_label)
ax2.scatter(x_cp_0, g_cp_0, color='k', label='Control point\nmetadata items')
ax2.scatter(x_cp_0, g_cp_0, color='k', facecolors='none', label='Control point\ntone map image')
ax2.plot(x, G_intr,                 color='k', linestyle=style_intr,     label=intr_label)

ax2.legend(handlelength=3, bbox_to_anchor=(1.05, 1),loc='upper left', borderaxespad=0.)
ax2.set_title('Gain functions')
ax2.set_xlabel('Input relative linear value $x$')
ax2.set_ylabel('$\\mathsf{Gain}(x)$')

fig.tight_layout()
ax1.grid(linestyle=grid_style);
ax2.grid(linestyle=grid_style);
plt.savefig('tonemap-intro.svg', transparent=True)

##
## HDR to SDR 2 curves
##

H = [0, np.log2(2), np.log2(4)]
M = np.exp2(H[-1])
Nw = [0.5, 1, 1]
C = []
for i in range(len(H)):
  M = np.exp2(H[-1])
  x_cp, y_cp = RwtmoBezierControlPoints(M, np.exp2(H[i]), Nw[i])
  # if i == 0:
  #   x_cp = np.array([0.6, 0.6*(1+0.75), 4.0])
  #   y_cp = np.array([0.4, 0.4*(1+0.75), 1.0])
  C.append(BezierToGainCurveControlPoints(x_cp, y_cp, 64))

x = np.linspace(0, M, 1000)

H_intr = np.log2(1.5)
G_intr, i, j, wi, wj = EvaluateWeightedGain(x, H_intr, H, C)
Y_intr = x * np.exp2(G_intr)
Y = [x * np.exp2(EvalGainCurve(x, c)) for c in C]

x_cp_0 = np.array([d['x'] for d in C[0]])
g_cp_0 = EvalGainCurve(x_cp_0, C[0])
y_cp_0 = x_cp_0 * np.exp2(g_cp_0)

fig, (ax2, ax1) = plt.subplots(1, 2, figsize=[9, 3])
ax1.plot(x, Y[2],   color='k', linestyle=style_base    )
ax1.plot(x, Y[1],   color='k', linestyle=style_altr[1] )
ax1.plot(x, Y[0],   color='k', linestyle=style_altr[0] )
ax1.plot(x, Y_intr, color='k', linestyle=style_intr    )
ax1.set_title('Tone mapping functions')
ax1.set_xlabel('Input relative linear value $x$')
ax1.set_ylabel('Tone mapped relative linear value\n$x\\times 2^{\mathsf{Gain}(x))}$')

base_label = 'Baseline\n$H_2=H_\\text{baseline}=\\log_2(4)=2$'
altr_labels = [
  'Alternate\n$H_1=H_{\\text{alt},1}=\\log_2(1)=1$',
  'Alternate\n$H_0=H_{\\text{alt},0}=\\log_2(1)=0$']
intr_label = 'Adapted\n$H_\\text{target}=\\log_2(%1.1f)\\approx%1.2f$' % (np.exp2(H_intr), H_intr)

ax2.plot(x, EvalGainCurve(x, C[2]), color='k', linestyle=style_base,    label=base_label)
ax2.plot(x, EvalGainCurve(x, C[1]), color='k', linestyle=style_altr[1], label=altr_labels[0])
ax2.plot(x, EvalGainCurve(x, C[0]), color='k', linestyle=style_altr[0], label=altr_labels[1])
ax2.plot(x, G_intr,                 color='k', linestyle=style_intr,    label=intr_label)

ax2.legend(handlelength=3, bbox_to_anchor=(1.05, 1),loc='upper left', borderaxespad=0.)
ax2.set_title('Gain functions')
ax2.set_xlabel('Input relative linear value $x$')
ax2.set_ylabel('$\\mathsf{Gain}(x)$')

fig.tight_layout()
ax1.grid(linestyle=grid_style);
ax2.grid(linestyle=grid_style);
plt.savefig('tonemap-intro-ex2.svg', transparent=True)

##
## SDR to HDR
##

C = C[::2]
H = H[::2]
C = InvertGainCurves(H, C, 1, 0)

M = np.exp2(H[0])
H_intr = np.log2(2)

base_label = 'Baseline\n$H_0=H_\\text{baseline}=\\log_2(1)=0$'
altr_labels = [
  'Alternate\n$H_1=H_{\\text{alt},0}=\\log_2(4)=2$']
intr_label = 'Adapted\n$H_\\text{target}=\\log_2(%1.f)=%1.f$' % (np.exp2(H_intr), H_intr)

x = np.linspace(0, M, 1000)

G_intr, i, j, wi, wj = EvaluateWeightedGain(x, H_intr, H, C)
Y_intr = x * np.exp2(G_intr)
Y = [x * np.exp2(EvalGainCurve(x, c)) for c in C]

x_cp_0 = np.array([d['x'] for d in C[0]])
g_cp_0 = EvalGainCurve(x_cp_0, C[0])
y_cp_0 = x_cp_0 * np.exp2(g_cp_0)

fig, (ax2, ax1) = plt.subplots(1, 2, figsize=[9, 3])
ax1.plot(x, Y[0],   color='k', linestyle=style_base,    label=base_label)
#ax1.plot(x, Y[1],   color='k', linestyle=style_altr[1], label=altr_labels[1])
#ax1.plot(x, Y[2],   color='k', linestyle=style_altr[0], label=altr_labels[0])
ax1.plot(x, Y[1],   color='k', linestyle=style_altr[0], label=altr_labels[0])
ax1.plot(x, Y_intr, color='k', linestyle=style_intr,    label=intr_label)
ax1.set_title('Tone mapping functions')
ax1.set_xlabel('Input relative linear value $x$')
ax1.set_ylabel('Tone mapped relative linear value\n$x\\times 2^{\mathsf{Gain}(x))}$')

ax2.plot(x, EvalGainCurve(x, C[0]), color='k', linestyle=style_base,    label=base_label)
#ax2.plot(x, EvalGainCurve(x, C[1]), color='k', linestyle=style_altr[1], label=altr_labels[1])
#ax2.plot(x, EvalGainCurve(x, C[2]), color='k', linestyle=style_altr[0], label=altr_labels[0])
ax2.plot(x, EvalGainCurve(x, C[1]), color='k', linestyle=style_altr[0], label=altr_labels[0])
ax2.plot(x, G_intr,                 color='k', linestyle=style_intr,    label=intr_label)

ax2.legend(handlelength=3, bbox_to_anchor=(1.05, 1),loc='upper left', borderaxespad=0.)
ax2.set_title('Gain functions')
ax2.set_xlabel('Input relative linear value $x$')
ax2.set_ylabel('$\\mathsf{Gain}(x)$')

fig.tight_layout()
ax1.grid(linestyle=grid_style);
ax2.grid(linestyle=grid_style);
plt.savefig('tonemap-intro-ex3.svg', transparent=True)
